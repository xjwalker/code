package main

type train interface {
	arrive()
	depart()
	permitArrival()
}
